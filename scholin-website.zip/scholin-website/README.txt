SCHOLIN WEBSITE
Upload ALL files in this folder to the ROOT of your GitHub Pages repository (replace the old ones):
index.html, privacy.html, terms.html, Scholin-Privacy-Policy.pdf, Scholin-Terms-and-Conditions.pdf
index.html is self contained: its pictures are built in, so no assets folder is needed.
If the old site still shows, refresh in a private tab.
The dashboard uses a fictional demo identity. The report card and vacancy screens use invented names.
